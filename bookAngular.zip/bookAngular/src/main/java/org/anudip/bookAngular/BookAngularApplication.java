package org.anudip.bookAngular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookAngularApplication.class, args);
	}

}
