package org.anudip.bookAngular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookAngularApplicationTests {

	@Test
	void contextLoads() {
	}

}
